package bean;

import java.io.Serializable;

public class User implements Serializable{
	private String userId;
	private String pw;
	private String name;
	private String phoneNum;
	private int shopNum;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public int getShopNum() {
		return shopNum;
	}
	public void setShopNum(int shopNum) {
		this.shopNum = shopNum;
	}
	public String toString(){
		return userId+", "+pw+", "+name+", "+phoneNum+", "+shopNum;
		
	}
	
}
